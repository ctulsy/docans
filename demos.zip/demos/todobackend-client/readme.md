# Todo-backend reference client

This is a todo app which uses the todo-backend API to store it's todos. 

# Provenance
This app is a slightly-modified version of the [TodoMVC Architecture Example for for backbone.js](https://github.com/tastejs/todomvc/tree/gh-pages/architecture-examples/backbone/js).
