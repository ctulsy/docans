#!/usr/bin/python
import os
print os.environ['VAULT_PASSWORD']