#!/bin/bash
. /appenv/bin/activate
exec $@